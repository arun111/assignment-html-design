Hi,

As per your design. i done development of the page using html, css and jquery.
Due to time shortage i have not done completely so you will get some bugs.